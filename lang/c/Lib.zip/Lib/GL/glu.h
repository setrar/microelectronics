#ifndef _GLU_INCLUDE
#define _GLU_INCLUDE	1

void gluPerspective(float Fovy, float Aspect, float NearClip, float FarClip);
void gluLookAt(float eyex,float eyey,float eyez,float centerx,float centery,float centerz,float upx,float upy,float upz);

#endif


